import jwt_decode from "jwt-decode"; // named import

export function isAdminTokenValid() {
  const token = localStorage.getItem("authToken");
  if (!token) return false;

  try {
    const decoded = jwt_decode(token); // Decoding the JWT token
    if (decoded.exp && decoded.exp * 1000 < Date.now()) {
      localStorage.removeItem("authToken");
      return false;
    }

    return true; // Token valid
  } catch (e) {
    localStorage.removeItem("authToken");
    return false; // Invalid token or error
  }
}
