import jwt_decode from "jwt-decode";

// Simpan token setelah login
export function setToken(token) {
  localStorage.setItem("token", token);
}

// Ambil token dari localStorage
export function getToken() {
  return localStorage.getItem("token");
}

// Hapus token (logout)
export function removeToken() {
  localStorage.removeItem("token");
}

// Cek apakah token ada & belum expired
export function isAuthenticated() {
  const token = getToken();
  if (!token) return false;

  try {
    const decoded = jwt_decode(token);
    const now = Date.now() / 1000;

    // Jika token punya exp & sudah lewat waktu → dianggap tidak valid
    if (decoded.exp && decoded.exp < now) {
      removeToken(); // hapus token kadaluarsa
      return false;
    }

    return true; // token valid
  } catch (err) {
    return false; // token rusak atau gagal decode
  }
}
