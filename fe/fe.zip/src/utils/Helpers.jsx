export const formatPercentage = (value) => {
	return `${value}%`;
};

export const calculateCertainty = (symptoms) => {
	// Logika perhitungan certainty factor
	return 85; // contoh
};
