import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import jwt_decode from "jwt-decode";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false); // Untuk state loading
  const [error, setError] = useState(""); // Untuk state error
  const navigate = useNavigate();

  // Cek token yang ada di localStorage saat pertama kali halaman dimuat
  useEffect(() => {
    const token = localStorage.getItem("authToken");
    if (token) {
      // Token ada, cek validitas dan arahkan ke /admin
      const decoded = jwt_decode(token);
      if (decoded.exp * 1000 > Date.now()) {
        navigate("/admin");
      } else {
        localStorage.removeItem("authToken"); // Token kadaluarsa
      }
    }
  }, [navigate]);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(""); // Reset error sebelum mencoba login

    try {
      const response = await axios.post(
        "http://127.0.0.1:5000/api/admin/login",
        {
          username,
          password,
        }
      );

      if (response.data.token) {
        // Simpan token di localStorage
        localStorage.setItem("authToken", response.data.token);
        localStorage.setItem("id_admin", response.data.id_admin); // Simpan ID admin jika diperlukan
        navigate("/admin"); // Arahkan ke halaman admin setelah login sukses
      }
    } catch (error) {
      setError(
        "Login gagal: " + (error.response?.data?.message || error.message)
      ); // Set error jika login gagal
      console.error(error);
    } finally {
      setLoading(false); // Reset loading state
    }
  };

  return (
    <div>
      <h1>Login Admin</h1>
      <form onSubmit={handleLogin}>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button type="submit" disabled={loading}>
          {loading ? "Loading..." : "Login"}
        </button>
      </form>
      {error && <p className="text-red-500">{error}</p>}{" "}
      {/* Tampilkan error jika ada */}
    </div>
  );
}
