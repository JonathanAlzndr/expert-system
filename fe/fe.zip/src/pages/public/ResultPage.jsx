import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Header from "../../components/common/Header";
import Footer from "../../components/common/Footer";
import Card from "../../components/ui/Card";
import Button from "../../components/ui/Button";

const ResultPage = () => {
	const navigate = useNavigate();
	const location = useLocation();
	const diagnosisResult = location.state?.diagnosisResult;

	// Debug log untuk melihat data yang diterima
	console.log("Diagnosis Result:", diagnosisResult);

	if (!diagnosisResult) {
		return (
			<div className="min-h-screen flex flex-col">
				<Header />
				<div className="flex-grow flex items-center justify-center bg-gray-100">
					<div className="text-center">
						<div className="bg-white rounded-lg shadow-lg p-8 max-w-md mx-4">
							<i className="fas fa-exclamation-triangle text-4xl text-yellow-500 mb-4"></i>
							<h2 className="text-2xl font-bold text-gray-800 mb-4">
								Data Hasil Diagnosis Tidak Ditemukan
							</h2>
							<p className="text-gray-600 mb-6">
								Silakan kembali ke halaman diagnosis untuk memulai proses diagnosis.
							</p>
							<Button onClick={() => navigate("/diagnosis")}>
								<i className="fas fa-arrow-left mr-2"></i> Kembali ke Diagnosis
							</Button>
						</div>
					</div>
				</div>
				<Footer />
			</div>
		);
	}

	// Handle berbagai format response dari backend
	const {
		hasil_utama = {},
		analisis_tambahan = [],
		id_diagnosis = "Tidak tersedia",
		msg = "",
		data = null,
		// Jika response langsung berisi data penyakit
		nama_penyakit,
		deskripsi,
		solusi,
		cf_tertinggi,
		id_penyakit,
	} = diagnosisResult;

	// Jika data ada di property 'data'
	const mainData = data || diagnosisResult;

	// Extract hasil utama dari berbagai kemungkinan format
	const mainResult = hasil_utama.nama_penyakit
		? hasil_utama
		: {
				nama_penyakit: nama_penyakit || mainData.nama_penyakit || "Tidak Terindikasi Penyakit",
				deskripsi:
					deskripsi ||
					mainData.deskripsi ||
					"Berdasarkan gejala yang Anda masukkan, sistem tidak menemukan indikasi kuat terhadap penyakit menular seksual.",
				solusi:
					solusi ||
					mainData.solusi ||
					"Tetap jaga kesehatan dan praktikkan perilaku seksual yang aman.",
				cf_tertinggi: cf_tertinggi || mainData.cf_tertinggi || mainData.cf_score || 0,
		  };

	// Handle case ketika tidak ada penyakit yang terdeteksi
	const noDiseaseDetected =
		!mainResult.nama_penyakit ||
		mainResult.nama_penyakit === "Tidak Terindikasi Penyakit" ||
		(mainResult.cf_tertinggi !== undefined && mainResult.cf_tertinggi <= 0);

	// Filter analisis tambahan yang memiliki CF score positif dan bukan hasil utama
	const additionalAnalysis = Array.isArray(analisis_tambahan) ? analisis_tambahan : [];
	const kemungkinanLain = additionalAnalysis
		.filter((item) => item.cf_score > 0 && item.id_penyakit !== mainResult.id_penyakit)
		.slice(0, 3); // Batasi maksimal 3 kemungkinan lain

	// Fungsi untuk mendapatkan nama penyakit berdasarkan ID
	const getNamaPenyakit = (idPenyakit) => {
		const penyakitMap = {
			P01: "Kandidiasis",
			P02: "Gonore",
			P03: "Sifilis",
			P04: "Herpes Genital",
			P05: "HIV/AIDS",
			P06: "Klamidia",
			P07: "Trikomoniasis",
		};
		return penyakitMap[idPenyakit] || `Penyakit ${idPenyakit}`;
	};

	// Tampilan untuk hasil "Tidak Terindikasi Penyakit"
	if (noDiseaseDetected) {
		return (
			<div className="min-h-screen flex flex-col bg-gray-50">
				<Header />

				<div className="flex-grow container mx-auto px-4 py-8">
					<nav className="flex mb-6" aria-label="Breadcrumb">
						<ol className="flex items-center space-x-2 text-sm text-gray-600">
							<li>
								<button
									onClick={() => navigate("/")}
									className="hover:text-primary transition duration-200"
								>
									Beranda
								</button>
							</li>
							<li>
								<i className="fas fa-chevron-right text-xs"></i>
							</li>
							<li>
								<button
									onClick={() => navigate("/diagnosis")}
									className="hover:text-primary transition duration-200"
								>
									Diagnosis
								</button>
							</li>
							<li>
								<i className="fas fa-chevron-right text-xs"></i>
							</li>
							<li className="text-primary font-medium">Hasil Diagnosis</li>
						</ol>
					</nav>

					<h1 className="text-3xl font-bold text-primary mb-2">Hasil Diagnosis</h1>

					<Card className="p-6 mb-8">
						<div className="flex items-center mb-4">
							<div className="bg-blue-100 text-blue-800 rounded-full w-12 h-12 flex items-center justify-center mr-4">
								<i className="fas fa-info-circle text-xl"></i>
							</div>
							<h2 className="text-2xl font-bold text-gray-800">Hasil Diagnosis</h2>
						</div>
						<div className="bg-blue-50 border border-blue-200 rounded-lg p-6 text-center">
							<i className="fas fa-check-circle text-6xl text-green-500 mb-4"></i>
							<h3 className="text-2xl font-bold text-gray-800 mb-4">{mainResult.nama_penyakit}</h3>
							<p className="text-gray-600 text-lg mb-4">{mainResult.deskripsi}</p>
							{mainResult.solusi && (
								<div className="bg-white rounded-lg p-4 inline-block max-w-2xl">
									<p className="text-gray-700">{mainResult.solusi}</p>
								</div>
							)}
						</div>
					</Card>

					<Card className="p-6 mb-8 bg-green-50 border-green-200">
						<div className="flex items-start">
							<i className="fas fa-thumbs-up text-green-500 text-xl mt-1 mr-3"></i>
							<div>
								<h3 className="text-lg font-semibold text-green-800 mb-2">Hasil Positif!</h3>
								<p className="text-green-700">
									Berdasarkan gejala yang Anda masukkan, sistem tidak menemukan indikasi kuat
									terhadap penyakit menular seksual. Tetap jaga kesehatan dan praktikkan perilaku
									seksual yang aman.
								</p>
							</div>
						</div>
					</Card>

					<div className="flex flex-col sm:flex-row justify-center gap-4">
						<Button
							onClick={() => navigate("/diagnosis")}
							className="bg-primary hover:bg-[#0e556b] transition duration-300"
						>
							<i className="fas fa-redo mr-2"></i> Diagnosis Ulang
						</Button>
						<Button onClick={() => navigate("/")} variant="secondary">
							<i className="fas fa-home mr-2"></i> Kembali ke Beranda
						</Button>
					</div>
				</div>

				<Footer />
			</div>
		);
	}

	// Tampilan normal untuk hasil penyakit tertentu
	return (
		<div className="min-h-screen flex flex-col bg-gray-50">
			<Header />

			<div className="flex-grow container mx-auto px-4 py-8">
				<nav className="flex mb-6" aria-label="Breadcrumb">
					<ol className="flex items-center space-x-2 text-sm text-gray-600">
						<li>
							<button
								onClick={() => navigate("/")}
								className="hover:text-primary transition duration-200"
							>
								Beranda
							</button>
						</li>
						<li>
							<i className="fas fa-chevron-right text-xs"></i>
						</li>
						<li>
							<button
								onClick={() => navigate("/diagnosis")}
								className="hover:text-primary transition duration-200"
							>
								Diagnosis
							</button>
						</li>
						<li>
							<i className="fas fa-chevron-right text-xs"></i>
						</li>
						<li className="text-primary font-medium">Hasil Diagnosis</li>
					</ol>
				</nav>

				<h1 className="text-3xl font-bold text-primary mb-2">Hasil Diagnosis</h1>
				<p className="text-gray-600 mb-8">
					Berikut adalah hasil diagnosis berdasarkan gejala yang Anda pilih
				</p>

				{/* Pesan dari server jika ada */}
				{msg && (
					<div className="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded mb-6">
						{msg}
					</div>
				)}

				{/* ID Diagnosis */}
				{id_diagnosis && id_diagnosis !== "Tidak tersedia" && (
					<div className="bg-gray-100 rounded-lg p-4 mb-6">
						<p className="text-gray-600 text-sm">
							<span className="font-semibold">ID Diagnosis:</span> {id_diagnosis}
						</p>
					</div>
				)}

				<Card className="p-6 mb-8">
					<div className="flex items-center mb-4">
						<div className="bg-green-100 text-green-800 rounded-full w-12 h-12 flex items-center justify-center mr-4">
							<i className="fas fa-check text-xl"></i>
						</div>
						<h2 className="text-2xl font-bold text-gray-800">Hasil Utama</h2>
					</div>
					<div className="bg-green-50 border border-green-200 rounded-lg p-6">
						<div className="flex flex-col md:flex-row justify-between items-start md:items-center">
							<div className="flex-1 mb-4 md:mb-0">
								<h3 className="text-2xl font-bold text-gray-800 mb-2">
									{mainResult.nama_penyakit}
								</h3>
								<p className="text-gray-600">{mainResult.deskripsi}</p>
							</div>
							<div className="text-center bg-white rounded-lg p-4 shadow-sm min-w-[120px]">
								<div className="text-3xl font-bold text-green-600 mb-1">
									{Math.round((mainResult.cf_tertinggi || 0) * 100)}%
								</div>
								<div className="text-sm text-gray-500 font-medium">Tingkat Keyakinan</div>
							</div>
						</div>
					</div>
				</Card>

				<Card className="p-6 mb-8">
					<div className="flex items-center mb-6">
						<div className="bg-blue-100 text-blue-800 rounded-full w-10 h-10 flex items-center justify-center mr-3">
							<i className="fas fa-info-circle"></i>
						</div>
						<h2 className="text-2xl font-bold text-gray-800">Detail & Solusi</h2>
					</div>
					<div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
						<div>
							<div className="flex items-center mb-3">
								<i className="fas fa-file-medical text-blue-500 mr-2"></i>
								<h3 className="text-lg font-semibold text-gray-700">Deskripsi Penyakit</h3>
							</div>
							<div className="bg-blue-50 rounded-lg p-4">
								<p className="text-gray-700 leading-relaxed">{mainResult.deskripsi}</p>
							</div>
						</div>
						<div>
							<div className="flex items-center mb-3">
								<i className="fas fa-hand-holding-medical text-green-500 mr-2"></i>
								<h3 className="text-lg font-semibold text-gray-700">Solusi & Perawatan</h3>
							</div>
							<div className="bg-green-50 rounded-lg p-4">
								<p className="text-gray-700 leading-relaxed">{mainResult.solusi}</p>
							</div>
						</div>
					</div>
				</Card>

				{kemungkinanLain.length > 0 && (
					<Card className="p-6 mb-8">
						<div className="flex items-center mb-6">
							<div className="bg-yellow-100 text-yellow-800 rounded-full w-10 h-10 flex items-center justify-center mr-3">
								<i className="fas fa-clipboard-list"></i>
							</div>
							<h2 className="text-2xl font-bold text-gray-800">Kemungkinan Lain</h2>
						</div>
						<p className="text-gray-600 mb-4">
							Penyakit lain yang memiliki kemungkinan (dalam persentase lebih rendah):
						</p>
						<div className="space-y-4">
							{kemungkinanLain.map((item, index) => (
								<div
									key={index}
									className="flex justify-between items-center p-4 border border-gray-200 rounded-lg hover:border-yellow-300 transition duration-200"
								>
									<div className="flex-1">
										<h3 className="text-lg font-semibold text-gray-700 mb-1">
											{getNamaPenyakit(item.id_penyakit)}
										</h3>
										<p className="text-gray-600 text-sm">Kemungkinan penyakit lainnya</p>
									</div>
									<div className="text-right">
										<div className="text-xl font-bold text-yellow-600">
											{Math.round(item.cf_score * 100)}%
										</div>
										<div className="text-sm text-gray-500">Tingkat Keyakinan</div>
									</div>
								</div>
							))}
						</div>
					</Card>
				)}

				<Card className="p-6 mb-8 bg-orange-50 border-orange-200">
					<div className="flex items-start">
						<i className="fas fa-exclamation-triangle text-orange-500 text-xl mt-1 mr-3"></i>
						<div>
							<h3 className="text-lg font-semibold text-orange-800 mb-2">Penting!</h3>
							<p className="text-orange-700">
								Hasil diagnosis ini bersifat prediktif berdasarkan sistem pakar. Disarankan untuk
								konsultasi dengan dokter profesional untuk diagnosis dan penanganan yang lebih
								akurat.
							</p>
						</div>
					</div>
				</Card>

				<div className="flex flex-col sm:flex-row justify-center gap-4">
					<Button
						onClick={() => navigate("/diagnosis")}
						className="bg-primary hover:bg-[#0e556b] transition duration-300"
					>
						<i className="fas fa-redo mr-2"></i> Diagnosis Ulang
					</Button>
					<Button onClick={() => navigate("/")} variant="secondary">
						<i className="fas fa-home mr-2"></i> Kembali ke Beranda
					</Button>
				</div>
			</div>

			<Footer />
		</div>
	);
};

export default ResultPage;
