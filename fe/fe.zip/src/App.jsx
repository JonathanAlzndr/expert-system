import { Routes, Route } from "react-router-dom";

/* layouts */
import Layout from "./layouts/Layout";
import LayoutAdmin from "./layouts/LayoutAdmin";

/* components */
import ProtectedRoute from "./components/ProtectedRoute";

/* pages */
import DashboardAdmin from "./pages/DashboardAdmin";
import Diagnosis from "./pages/Diagnosis";
import LandingPage from "./pages/LandingPage";
import LoginPage from "./pages/LoginPage";
import DiagnosisResults from "./pages/DiagnosisResults";

function App() {
  return (
    <Routes>
      {/* ========== PUBLIC ROUTES ========== */}
      <Route path="/" element={<Layout />}>
        <Route index element={<LandingPage />} />
        <Route path="diagnosis" element={<Diagnosis />} />
        <Route path="diagnosis/results" element={<DiagnosisResults />} />
      </Route>

      {/* LOGIN */}
      <Route path="/login" element={<LoginPage />} />

      {/* ========== ADMIN (PROTECTED) ========== */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute>
            <LayoutAdmin />
          </ProtectedRoute>
        }
      >
        {/* Parent admin sudah protected → semua child ikut aman */}
        <Route index element={<DashboardAdmin />} />
        <Route path="dashboard" element={<DashboardAdmin />} />
        {/* kamu bisa tambahkan child lain nanti */}
      </Route>
    </Routes>
  );
}

export default App;
